# Databricks notebook source
raw_folder_path = "/mnt/storagedlformula1/raw"
processed_folder_path = "/mnt/storagedlformula1/processed"
presentation_folder_path = "/mnt/storagedlformula1/presentation"