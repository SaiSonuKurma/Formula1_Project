-- Databricks notebook source
SELECT team_name,
       count(*) as total_races,
       sum(calculated_points) as total_points,
       avg(calculated_points) as avg_points
  from f1_presentation.calculated_race_results
  GROUP BY team_name
  having total_races >=100
  order by avg_points desc

-- COMMAND ----------

SELECT team_name,
       count(*) as total_races,
       sum(calculated_points) as total_points,
       avg(calculated_points) as avg_points
  from f1_presentation.calculated_race_results
  where race_year BETWEEN 2000 and 2020
  GROUP BY team_name
  having total_races >=100
  order by avg_points desc